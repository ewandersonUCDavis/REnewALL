/***** XBEE APPLICATION PROJECT *****
 * 
 * Auto-generated header with information about the 
 * relation between the XBee module pins and the 
 * project components.
 * 
 ************ XBEE LAYOUT ***********
 * 
 * This layout represents the XBee-PRO 900HP DigiMesh (S3B) module 
 * selected for the project with its pin distribution:
 *               _________________
 *              /     ________    \ 
 *             /     |   __   |    \ 
 *            /      | //  \\ |     \ 
 *   XPIN1  -|       | \\__// |      |- XPIN20
 *   XPIN2  -|       |________|      |- XPIN19
 *   XPIN3  -|                       |- XPIN18
 *   XPIN4  -| ===================== |- XPIN17
 *   XPIN5  -| #   # ####  #### #### |- XPIN16
 *   XPIN6  -|  # #  #   # #    #    |- XPIN15
 *   XPIN7  -|   #   ####  ###  ###  |- XPIN14
 *   XPIN8  -|  # #  #   # #    #    |- XPIN13
 *   XPIN9  -| #   # ####  #### #### |- XPIN12
 *   XPIN10 -| ===================== |- XPIN11
 *           |_______________________|
 * 
 ************ PINS LEGEND ***********
 * 
 * The following list displays all the XBee Module pins 
 * with the project component which is using each one:
 * 
 *   XPIN1 = VCC
 *   XPIN2 = uart0 [TX Pin]
 *   XPIN3 = uart0 [RX Pin]
 *   XPIN4 = stop_button [GPIO Pin]
 *   XPIN5 = special0 [Reset Pin]
 *   XPIN6 = <<UNUSED>>
 *   XPIN7 = start_button [GPIO Pin]
 *   XPIN8 = special0 [BKGD Pin]
 *   XPIN9 = <<UNUSED>>
 *   XPIN10 = GND
 *   XPIN11 = <<UNUSED>>
 *   XPIN12 = <<UNUSED>>
 *   XPIN13 = <<UNUSED>>
 *   XPIN14 = VCC REF
 *   XPIN15 = special0 [Association Pin]
 *   XPIN16 = <<UNUSED>>
 *   XPIN17 = <<UNUSED>>
 *   XPIN18 = <<UNUSED>>
 *   XPIN19 = pulseDetect [IRQ Pin]
 *   XPIN20 = special0 [Commissioning Pin]
 *
 ************************************/


#include <xbee_config.h>
#include <types.h>

#include <stdio.h>
#include <stdlib.h>
#include <xbee/discovery.h>
#include <xbee/transparent_serial.h>
#include <xbee/byteorder.h>
#include <xbee/atcmd.h>

#define MONITOR_NI 	"MONITOR"

uint16_t pulse_count = 0; //This is a power pulse count that is transmitted to the central office then reset every 15 minutes.
uint16_t threshold_pulse_count = 0; //this is a power pulse count that is reset every minute.
uint16_t threshold = 0; // this is a soft shutdown threshold provided by the central office controller. If threshold_pulse_count is less than this and the turbine is on, then the turbine is shut down.

/* Timer signaled a new sample has to be taken */
bool_t send_pulse_count = FALSE;
/* This flag indicates that it's time to check the short term (1 minute) threshold_pulse_count against the soft shutdown threshold */
bool_t check_threshold = TRUE;


wpan_envelope_t env;

/* Buffer used to transmit samples over the air
 * dimensioned for a 16bit sample plus the terminator
 */
char txbuf[sizeof(pulse_count) + 1];

/* Signal when monitor discover is in progress */
bool_t nd_in_progress = FALSE;

/* Monitor ieeeaddr resolved by xbee_disc_discover_nodes() */
addr64 monitor_ieeeaddr;

/* Keeps MONITOR information and configure send envelop accordingly */
void set_monitor(const xbee_node_id_t *node_id)
{
	char addr_buffer[ADDR64_STRING_LENGTH];

	memcpy(&monitor_ieeeaddr, &node_id->ieee_addr_be, sizeof(monitor_ieeeaddr));
	
	printf("MONITOR is %s\n", addr64_format(addr_buffer, &monitor_ieeeaddr));
	
	wpan_envelope_create(&env, &xdev.wpan_dev, &monitor_ieeeaddr,
											 WPAN_NET_ADDR_UNDEFINED);
	env.payload = txbuf;
	env.length = 2;
	
	/* Simulate Commissioning Button press so a Node Identification broadcast 
	 * transmission is queued to be sent at the beginning of the next network 
	 * wake cycle. This way the MONITOR will know our NI.
	 */
	(void)xbee_cmd_simple(&xdev, "CB", 1);
}

#ifdef ENABLE_XBEE_HANDLE_ND_RESPONSE_FRAMES
void node_discovery_callback(xbee_dev_t *xbee, const xbee_node_id_t *node_id)
{
	/* This function is called every time a node is discovered, either by
	 * receiving a NodeID message or because a node search was started with
	 * function xbee_disc_discover_nodes() */

	if (node_id == NULL) {
		printf("Node Discovery timed out\n");
		nd_in_progress = FALSE;
		return;
	}
	
	if (strncmp(node_id->node_info, MONITOR_NI, strlen(MONITOR_NI)) == 0) {
		set_monitor(node_id);
		nd_in_progress = FALSE;
	}

	return;
}
#endif

//The purpose of this function is to process transmit status messages, which are return messages indicating if the a message sent by this xbee was recieved. Could be useful, but I'm not really doing anything with it yet.
#ifdef ENABLE_XBEE_HANDLE_TX_STATUS_FRAMES
int xbee_transmit_status_handler(xbee_dev_t *xbee, const void FAR *payload,
                                 uint16_t length, void FAR *context)
{
	const xbee_frame_transmit_status_t FAR *frame = payload;
	//printf("Transmit status message: #X%x\n", *frame); //I clearly don't understand the transmit status messages we're receiving. COme back to this.

	/* it may be necessary to push information up to user code so they know when
	 * a packet has been received or if it didn't make it out.
	 */
	/*printf( "TransmitStatus: id 0x%02x retries=%d del=0x%02x disc=0x%02x\n",
	      frame->frame_id,
	      frame->retries, frame->delivery,
	      frame->discovery);*/

	return 0;
}
#endif

#if defined(RTC_ENABLE_PERIODIC_TASK)
void rtc_periodic_task(void)
{
	send_pulse_count = TRUE; //15 minutes have passed. It's time to send the pulse count.
}
#endif


#ifdef pulseDetect_irq
void pulseDetect_irq(void)
{
	pulse_count++; //Count this pulse
	printf("pulse_count = %u\n", pulse_count);
	threshold_pulse_count++;
}
#endif

#ifdef ENABLE_XBEE_HANDLE_RX
int xbee_transparent_rx(const wpan_envelope_t FAR *envelope, void FAR *context)
{
	char message[10];
	char * temp;
	
	strcpy(message, envelope->payload);
	printf("Message recieved:   %s\n", message);

	if (!strncmp(message,"start",5)) { //Check to see if the first five letters in the message payload are "start"
		printf("Initiating turbine start sequence. \n");
		gpio_set(start_button, TRUE); //Set start_button output pin to high.
		timer_config(start_sequence_timer, TRUE, ONE_SHOT, 500000); //Call timer to reset the start_button output pin to low after 0.5 s.  
	} else if (!strncmp(message,"stop",4)) { //Check to see if the first five letters in the message payload are "stop"
		printf("Initiating turbine stop sequence. \n");
		gpio_set(stop_button, TRUE);
		timer_config(stop_sequence_timer, TRUE, ONE_SHOT, 500000); //Call timer to reset the stop_button output pin to low after 0.5 s.
	} else if (!strncmp(message,"T",1)) { //Check to see if the first letter in the message payload is "T" (for threshold)
		printf("New soft shutdown threshold received. \n");
		temp = strtok (message+1,"T"); //Assign the part of the message between the "T"s to string temp.
		threshold = atoi(temp); //Convert string temp to an int and assign it to threshold.
		printf("Threshold : %u\n",threshold);
		printf("Threshold_pulse_count : %u\n",threshold_pulse_count);
		if (threshold_pulse_count == 0) threshold_pulse_count = 1; //This line addresses the scenario where the turbine is not producing power when a soft shutdown command is received. The logic below initiates a turbine stop when threshold_pulse_count is less than the threshold and != 0. This line ensures threshold_pulse_count will not = 0 the first time the threshold is checked. 
		printf("Threshold_pulse_count : %u\n",threshold_pulse_count);
	}
	return 0;
}
#endif

#ifdef stop_sequence_timer_irq 
void stop_sequence_timer_irq(void)
{
	gpio_set(stop_button, FALSE); //after 0.5 s delay set the stop_button output pin back to low.
}
#endif

#ifdef start_sequence_timer_irq 
void start_sequence_timer_irq(void)
{
	gpio_set(start_button, FALSE); //after 0.5 s delay set the start_button output pin back to low.
}
#endif

#ifdef threshold_timer_irq 
void threshold_timer_irq(void)
{
	check_threshold = TRUE; //It has been a minute since we last checked the soft shutdown threshold. Check it again.
}
#endif

void main(void)
{	
	sys_hw_init(); 
	sys_xbee_init();
	sys_app_banner();
	
#ifdef XBEE_ATCMD_PARAM_NI
	printf("Starting using NI = %s\n", XBEE_ATCMD_PARAM_NI);
#else
	printf("NI parameter not configured. You should configure it!!!.\n");
#endif
	
	// set initial values for start_button and stop_button output pins.
	gpio_set(stop_button, FALSE);
	gpio_set(start_button, FALSE);
	
	memset(txbuf, 0, sizeof(txbuf));
	
	for (;;) {		
		if (!nd_in_progress && addr64_is_zero(&monitor_ieeeaddr)) {
			printf("MONITOR not yet discovered. Sending DiscoverNode\n");
			xbee_disc_discover_nodes(&xdev, MONITOR_NI);
			nd_in_progress = TRUE;
		}

		/* Sample and send packet */
		if (send_pulse_count) {
			send_pulse_count = FALSE;
			if (addr64_is_zero(&monitor_ieeeaddr)) 
				printf("MONITOR not yet discovered. Sample lost\n");
			else {
				printf("transmitting 15 minute pulse count: %u\n", pulse_count);
				*(uint16_t*)txbuf = pulse_count;
				xbee_transparent_serial(&env);
				pulse_count = 0;
			}
		}
		if (check_threshold) {
			check_threshold = FALSE;
			printf("Checking shutdown threshold. Threshold_pulse_count = %u and  threshold  = %u. \n",threshold_pulse_count,threshold);
			timer_config(threshold_timer, TRUE, ONE_SHOT, 30000000); //Call timer to reset the check_threshold to TRUE after 30 s.
			if ((threshold_pulse_count < threshold) && (threshold_pulse_count != 0)) {
				printf("Initiating turbine stop sequence based on threshold_pulse_count (%u)and  threshold (%u). \n",threshold_pulse_count,threshold);
				gpio_set(stop_button, TRUE);
				timer_config(stop_sequence_timer, TRUE, ONE_SHOT, 500000); //Call timer to reset the stop_button output pin to low after 0.5 s.
			}
			threshold_pulse_count = 0;
		}
		sys_watchdog_reset();
		sys_xbee_tick();
	}
}
